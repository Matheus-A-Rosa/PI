# Projeto MUNDOMÁTICA / Primeira Fase

	Esse projeto foi criado por Matheus Rosa, Victor Santiago, Vinícios Santiago e Yuri Ranieri, somos alunos da primeira
fase do curso de Análise e Desenvolvimento de Sistemas do Senai de Florianópolis(CTAI).

	A ideia e aplicação do projeto surgirram a partir de uma proposta do curso, tivemos grande afinidade com esse tema 
e curiosidade de como seria desenvolver algo ligado ao ensino. Nossa motivação e entusiasmo aumentavão cada vez mais enquanto
discutiamos as funcionalidades do aplicativo e sobre seus benefícios, além de a quais plataformas e hardwares o mesmo poderia
ter interação, desde a base das ideais iniciais até a montagem do site nos empenhamos com carinho para entregar nosso melhor.

